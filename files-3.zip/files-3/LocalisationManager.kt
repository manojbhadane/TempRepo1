package com.yourapp.localisation

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.regex.Pattern

/**
 * ─────────────────────────────────────────────────────────────
 * LocalisationManager
 * ─────────────────────────────────────────────────────────────
 * Central singleton for dynamic string localisation.
 * Strings are fetched from a backend API per language and stored
 * here. Falls back to strings.xml (English) if a key is missing.
 *
 * SETUP — call once in Application.onCreate():
 *   LocalisationManager.init(this)
 *
 * LOAD — call after your API response:
 *   LocalisationManager.loadStrings("fr", apiResponse)
 *
 * USAGE:
 *   loc("welcome_title")                          // static
 *   loc("greeting", "name" to "Alice")            // named token
 *   locf("intro", "Alice", 30)                    // printf-style
 *
 * ─── Fallback chain ───────────────────────────────────────────
 *   1. API strings      → ConcurrentHashMap O(1) lookup
 *   2. strings.xml      → pre-loaded cache O(1) lookup
 *   3. Key itself       → never crashes, never blank
 *
 * ─── Placeholder formats (auto-detected) ─────────────────────
 *   Named    "Hi {name}, you have {count} messages"
 *   Printf   "Hi %s, you have %d messages"
 *   Indexed  "Hi {0}, you have {1} messages"
 *
 * ─── Key design decisions ────────────────────────────────────
 *   • ConcurrentHashMap     — thread-safe: API callback writes
 *                             from background, UI reads from main
 *   • XML pre-loaded once   — no repeated getIdentifier() calls
 *                             at runtime; fallback is O(1)
 *   • Resolved string cache — same key+args always returns the
 *                             same string; allocation avoided
 *   • Locale.ROOT for printf— prevents Arabic-Indic numeral
 *                             substitution on %d; silences Lint
 *   • context.getString()   — used for XML printf so Android
 *                             resource system handles locale
 *   • applicationContext    — never holds Activity reference
 * ─────────────────────────────────────────────────────────────
 */
object LocalisationManager {

    // ── Storage ───────────────────────────────────────────────
    private val apiStrings      = ConcurrentHashMap<String, String>()
    private val xmlFallbackCache = ConcurrentHashMap<String, String>()
    private val resolvedCache   = ConcurrentHashMap<String, String>()
    private var appContext: Context? = null

    // ── State ─────────────────────────────────────────────────
    private val _localisationReady  = MutableLiveData(false)
    private val _languageChanged    = MutableLiveData<String>()

    val localisationReady: LiveData<Boolean> = _localisationReady
    val languageChanged:   LiveData<String>  = _languageChanged

    var currentLanguage: String = "en"
        private set

    // ── Regex patterns (compiled once) ────────────────────────
    private val PRINTF_PATTERN  = Pattern.compile("%[sdfbcoxX%]")
    private val NAMED_PATTERN   = Pattern.compile("\\{[a-zA-Z_][a-zA-Z0-9_]*\\}")
    private val INDEXED_PATTERN = Pattern.compile("\\{\\d+\\}")

    // ─────────────────────────────────────────────────────────
    // INIT — call in Application.onCreate()
    // Pre-loads strings.xml into cache (paid once at startup).
    // ─────────────────────────────────────────────────────────
    fun init(context: Context) {
        appContext = context.applicationContext
        preloadXmlStrings(context.applicationContext)
    }

    private fun preloadXmlStrings(context: Context) {
        try {
            val res         = context.resources
            val packageName = context.packageName
            val stringClass = Class.forName("$packageName.R\$string")
            stringClass.fields.forEach { field ->
                try {
                    xmlFallbackCache[field.name] = res.getString(field.getInt(null))
                } catch (_: Exception) { }
            }
        } catch (_: Exception) { }
    }

    // ─────────────────────────────────────────────────────────
    // LOAD — call after API response with new language strings
    // Atomic swap: resolved cache cleared before map replaced,
    // so readers never see a partially-updated state.
    // ─────────────────────────────────────────────────────────
    fun loadStrings(language: String, stringsMap: Map<String, String>) {
        currentLanguage = language
        resolvedCache.clear()
        apiStrings.clear()
        apiStrings.putAll(stringsMap)
        _localisationReady.postValue(true)
        _languageChanged.postValue(language)
    }

    // ─────────────────────────────────────────────────────────
    // getString — static, no placeholders (fast path)
    // ─────────────────────────────────────────────────────────
    fun getString(key: String): String =
        apiStrings[key] ?: xmlFallbackCache[key] ?: key

    // ─────────────────────────────────────────────────────────
    // format — named tokens {name} {count}   ← RECOMMENDED
    //
    //   format("greeting", "name" to "Alice", "count" to 5)
    //   Backend: "Hi {name}, you have {count} messages"
    //   Result:  "Hi Alice, you have 5 messages"
    //
    //   Named tokens let the backend reorder args per language
    //   (important for Arabic, Hindi, RTL languages). Printf
    //   forces fixed argument order across all translations.
    // ─────────────────────────────────────────────────────────
    fun format(key: String, vararg namedArgs: Pair<String, Any>): String {
        val raw = apiStrings[key] ?: xmlFallbackCache[key] ?: return key
        if (namedArgs.isEmpty()) return raw

        val cacheKey = buildNamedCacheKey(key, namedArgs)
        resolvedCache[cacheKey]?.let { return it }

        return applyNamedTokens(raw, namedArgs)
            .also { resolvedCache[cacheKey] = it }
    }

    // ─────────────────────────────────────────────────────────
    // format — printf-style %s %d %f
    //
    //   format("intro", "Alice", 30)
    //   Backend: "My name is %s and age is %d"
    //   Result:  "My name is Alice and age is 30"
    //
    //   Two paths by source:
    //     API string → String.format(Locale.ROOT, …)
    //       Locale.ROOT prevents Arabic-Indic numeral substitution
    //       and silences Android Lint ImplicitDefaultLocale.
    //     XML string → context.getString(resId, …)
    //       Android-idiomatic: resource system handles locale.
    //
    //   Also handles {0} {1} indexed format automatically.
    // ─────────────────────────────────────────────────────────
    fun format(key: String, vararg printfArgs: Any): String {
        if (printfArgs.isEmpty()) return getString(key)

        val apiRaw = apiStrings[key]
        if (apiRaw != null) {
            return when (detectFormat(apiRaw)) {
                PlaceholderFormat.PRINTF  -> applyPrintf(apiRaw, printfArgs)
                PlaceholderFormat.INDEXED -> applyIndexed(apiRaw, printfArgs)
                else                      -> apiRaw
            }
        }

        return applyPrintfFromXml(key, printfArgs) ?: key
    }

    // ─────────────────────────────────────────────────────────
    // getString — legacy Map API (backwards compatible)
    //   getString("key", mapOf("{name}" to "Alice"))
    // ─────────────────────────────────────────────────────────
    fun getString(key: String, placeholders: Map<String, String>): String {
        if (placeholders.isEmpty()) return getString(key)
        val raw      = apiStrings[key] ?: xmlFallbackCache[key] ?: return key
        val cacheKey = buildMapCacheKey(key, placeholders)
        resolvedCache[cacheKey]?.let { return it }
        return applyNamedBraces(raw, placeholders)
            .also { resolvedCache[cacheKey] = it }
    }

    fun getString(key: String, vararg args: Pair<String, String>): String =
        getString(key, mapOf(*args))

    // ─────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────
    fun hasKey(key: String): Boolean = apiStrings.containsKey(key)

    fun getAllStrings(): Map<String, String> = HashMap(apiStrings)

    fun clear() {
        apiStrings.clear()
        resolvedCache.clear()
        _localisationReady.postValue(false)
    }

    fun resolveSource(key: String): StringSource = when {
        apiStrings.containsKey(key)       -> StringSource.API
        xmlFallbackCache.containsKey(key) -> StringSource.XML_FALLBACK
        else                              -> StringSource.KEY_FALLBACK
    }

    enum class StringSource { API, XML_FALLBACK, KEY_FALLBACK }

    // ─────────────────────────────────────────────────────────
    // Internal — format detection
    // ─────────────────────────────────────────────────────────
    private enum class PlaceholderFormat { PRINTF, NAMED, INDEXED, NONE }

    private fun detectFormat(raw: String): PlaceholderFormat = when {
        PRINTF_PATTERN.matcher(raw).find()   -> PlaceholderFormat.PRINTF
        INDEXED_PATTERN.matcher(raw).find()  -> PlaceholderFormat.INDEXED
        NAMED_PATTERN.matcher(raw).find()    -> PlaceholderFormat.NAMED
        else                                 -> PlaceholderFormat.NONE
    }

    // ─────────────────────────────────────────────────────────
    // Internal — format engines
    // ─────────────────────────────────────────────────────────
    private fun applyPrintf(raw: String, args: Array<out Any>): String =
        try { String.format(Locale.ROOT, raw, *args) } catch (_: Exception) { raw }

    private fun applyPrintfFromXml(key: String, args: Array<out Any>): String? {
        val ctx = appContext ?: return xmlFallbackCache[key]
        return try {
            val resId = ctx.resources.getIdentifier(key, "string", ctx.packageName)
            if (resId != 0) ctx.getString(resId, *args) else null
        } catch (_: Exception) { xmlFallbackCache[key] }
    }

    private fun applyNamedTokens(raw: String, args: Array<out Pair<String, Any>>): String {
        var result = raw
        args.forEach { (name, value) -> result = result.replace("{$name}", value.toString()) }
        return result
    }

    private fun applyNamedBraces(raw: String, placeholders: Map<String, String>): String {
        var result = raw
        placeholders.forEach { (token, value) ->
            val k = if (token.startsWith("{") && token.endsWith("}")) token else "{$token}"
            result = result.replace(k, value)
        }
        return result
    }

    private fun applyIndexed(raw: String, args: Array<out Any>): String {
        var result = raw
        args.forEachIndexed { i, v -> result = result.replace("{$i}", v.toString()) }
        return result
    }

    // ─────────────────────────────────────────────────────────
    // Internal — cache key builders
    // ─────────────────────────────────────────────────────────
    private fun buildNamedCacheKey(key: String, args: Array<out Pair<String, Any>>): String =
        buildString {
            append(key)
            args.sortedBy { it.first }.forEach { (k, v) ->
                append('|').append(k).append('=').append(v)
            }
        }

    private fun buildMapCacheKey(key: String, placeholders: Map<String, String>): String =
        buildString {
            append(key)
            placeholders.entries.sortedBy { it.key }.forEach { (k, v) ->
                append('|').append(k).append('=').append(v)
            }
        }
}

package com.yourapp.localisation

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import java.lang.ref.WeakReference

/**
 * ─────────────────────────────────────────────────────────────
 * LocalisationViewBinder
 * ─────────────────────────────────────────────────────────────
 * Maps localisation keys to Views, and re-applies strings
 * automatically when the language changes.
 *
 * THREE ways to bind a view:
 *
 *   1. XML tag (declarative — zero Kotlin needed)
 *      android:tag="loc:welcome_title"
 *      android:tag="loc:email_hint|HINT"
 *
 *   2. Extension functions (programmatic)
 *      myTextView.setLocalisedText("welcome_title")
 *      myEditText.setLocalisedHint("email_hint")
 *
 *   3. Direct bind (manual)
 *      LocalisationViewBinder.bind(view, "key", ViewProperty.TEXT)
 *
 * ─── Key design decisions ────────────────────────────────────
 *   • WeakReference<View>  — bindings never prevent Activity/
 *                            View from being garbage collected
 *   • Auto dead-view prune — applyAll() removes stale refs;
 *                            no need to always call clearBindings()
 *   • Deduplication        — same view+key never stored twice;
 *                            safe to call bind() multiple times
 *   • Subclass order       — EditText → Button → TextView:
 *                            both extend TextView, must check
 *                            subclass first or wrong branch fires
 * ─────────────────────────────────────────────────────────────
 */
object LocalisationViewBinder {

    enum class ViewProperty { TEXT, HINT, CONTENT_DESCRIPTION, ERROR }

    data class ViewBinding(
        val viewRef:        WeakReference<View>,
        val key:            String,
        val targetProperty: ViewProperty        = ViewProperty.TEXT,
        val placeholders:   Map<String, String> = emptyMap()
    )

    private val bindings = mutableListOf<ViewBinding>()

    // ─────────────────────────────────────────────────────────
    // bind — register a View programmatically
    // Safe to call multiple times — dedup prevents double-entry.
    // Always applies the current string immediately.
    // ─────────────────────────────────────────────────────────
    fun bind(
        view:         View,
        key:          String,
        property:     ViewProperty        = ViewProperty.TEXT,
        placeholders: Map<String, String> = emptyMap()
    ) {
        val alreadyBound = bindings.any { b ->
            b.viewRef.get() === view &&
            b.key            == key  &&
            b.targetProperty == property
        }
        if (!alreadyBound) {
            bindings.add(ViewBinding(WeakReference(view), key, property, placeholders))
        }
        applyToView(view, key, property, placeholders)
    }

    // ─────────────────────────────────────────────────────────
    // Scan helpers — call from Activity/Fragment after setContentView
    // ─────────────────────────────────────────────────────────
    fun bindActivity(activity: Activity) =
        scanAndBind(activity.window.decorView.rootView)

    fun bindFragment(fragment: Fragment) =
        fragment.view?.let { scanAndBind(it) }

    fun bindView(rootView: View) =
        scanAndBind(rootView)

    // ─────────────────────────────────────────────────────────
    // applyAll — re-apply all live bindings after language change.
    // Dead WeakReferences (destroyed Activities) pruned silently.
    // ─────────────────────────────────────────────────────────
    fun applyAll() {
        val iterator = bindings.iterator()
        while (iterator.hasNext()) {
            val binding = iterator.next()
            val view    = binding.viewRef.get()
            if (view == null) iterator.remove()   // GC'd — prune
            else applyToView(view, binding.key, binding.targetProperty, binding.placeholders)
        }
    }

    // ─────────────────────────────────────────────────────────
    // clearBindings — explicit teardown (logout, full reset).
    // Not required for normal Activity lifecycle — applyAll()
    // prunes dead views automatically.
    // ─────────────────────────────────────────────────────────
    fun clearBindings() = bindings.clear()

    // ─────────────────────────────────────────────────────────
    // Internal — scan View tree for loc: tags
    //
    // Tag format:
    //   "loc:key"           → binds TEXT property
    //   "loc:key|HINT"      → binds HINT property
    //   "loc:key|ERROR"     → binds ERROR property
    //   "loc:key|CONTENT_DESCRIPTION"
    // ─────────────────────────────────────────────────────────
    private fun scanAndBind(view: View) {
        val tag = view.tag as? String
        if (tag != null && tag.startsWith("loc:")) {
            val parts    = tag.removePrefix("loc:").split("|")
            val key      = parts[0].trim()
            val property = parts.getOrNull(1)?.trim()?.uppercase()
                ?.let { runCatching { ViewProperty.valueOf(it) }.getOrNull() }
                ?: ViewProperty.TEXT
            bind(view, key, property)
        }
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) scanAndBind(view.getChildAt(i))
        }
    }

    // ─────────────────────────────────────────────────────────
    // Internal — apply resolved string to the right view property.
    //
    // Subclass order matters:
    //   EditText extends TextView — must check EditText first.
    //   Button  extends TextView — must check Button  first.
    //   If TextView is checked first, the subclass branch never fires.
    // ─────────────────────────────────────────────────────────
    private fun applyToView(
        view:         View,
        key:          String,
        property:     ViewProperty,
        placeholders: Map<String, String> = emptyMap()
    ) {
        val text = LocalisationManager.getString(key, placeholders)
        when (property) {
            ViewProperty.TEXT -> when (view) {
                is EditText -> view.setText(text)
                is Button   -> view.text = text
                is TextView -> view.text = text
            }
            ViewProperty.HINT -> when (view) {
                is EditText -> view.hint = text
                is TextView -> view.hint = text
            }
            ViewProperty.CONTENT_DESCRIPTION -> view.contentDescription = text
            ViewProperty.ERROR -> (view as? TextView)?.error = text
        }
    }
}

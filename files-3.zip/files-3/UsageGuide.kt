package com.yourapp

/**
 * ─────────────────────────────────────────────────────────────
 * COMPLETE USAGE GUIDE
 * ─────────────────────────────────────────────────────────────
 */

// ═══════════════════════════════════════════════════════════════
// STEP 1 — Application class
// ═══════════════════════════════════════════════════════════════

import android.app.Application
import com.yourapp.localisation.LocalisationManager

class MyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        LocalisationManager.init(this)   // pre-loads strings.xml fallback
    }
}

// AndroidManifest.xml:
//   <application android:name=".MyApplication" .../>


// ═══════════════════════════════════════════════════════════════
// STEP 2 — Load strings after your API call
// ═══════════════════════════════════════════════════════════════

// yourApiService.getStrings(languageCode) { response ->
//     LocalisationManager.loadStrings(languageCode, response)
//     // All Activities/Fragments observing LiveData update automatically
// }

// Example API response map:
val exampleApiResponse = mapOf(
    "welcome_title"    to "Bienvenue",
    "login_button"     to "Se connecter",
    "email_hint"       to "Entrez votre e-mail",
    "greeting"         to "Bonjour {name}, vous avez {count} messages",
    "profile_intro"    to "Je m'appelle %s et j'ai %d ans",
    "item_label"       to "Élément {0} sur {1}",
    "error_network"    to "Pas de connexion Internet"
)

LocalisationManager.loadStrings("fr", exampleApiResponse)


// ═══════════════════════════════════════════════════════════════
// STEP 3a — XML layout (declarative, zero Kotlin needed)
// ═══════════════════════════════════════════════════════════════

/*
<TextView
    android:tag="loc:welcome_title"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"/>

<EditText
    android:tag="loc:email_hint|HINT"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"/>

<Button
    android:tag="loc:login_button"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"/>

<!-- Tag format: "loc:key"  or  "loc:key|PROPERTY" -->
<!-- PROPERTY options: TEXT (default), HINT, ERROR, CONTENT_DESCRIPTION -->
*/


// ═══════════════════════════════════════════════════════════════
// STEP 3b — Activity using base class (auto-wires everything)
// ═══════════════════════════════════════════════════════════════

import com.yourapp.localisation.LocalisationActivity
import com.yourapp.localisation.formatText
import com.yourapp.localisation.loc
import com.yourapp.localisation.locf
import com.yourapp.localisation.setLocalisedHint
import com.yourapp.localisation.setLocalisedText

class LoginActivity : LocalisationActivity() {

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        // Views with android:tag="loc:..." are auto-bound — nothing else needed
    }

    override fun onLocalisationApplied() {
        // Called after every language load/change.
        // Use this for views that need dynamic values.
        val userName = "Alice"
        val messageCount = 5

        // Named tokens — RECOMMENDED
        greetingView.formatText("greeting", "name" to userName, "count" to messageCount)

        // printf-style (when backend sends %s/%d)
        introView.text = locf("profile_intro", userName, 30)

        // Indexed (when backend sends {0} {1})
        itemLabel.text = loc("item_label", "1", "10")   // loc() with named Pairs
    }

    override fun onLanguageChanged(language: String) {
        // Called just before views are re-bound
        // e.g. update RTL layout direction
    }
}


// ═══════════════════════════════════════════════════════════════
// STEP 3c — Manual wiring (without base class)
// ═══════════════════════════════════════════════════════════════

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        // Static
        titleView.setLocalisedText("settings_title")
        searchInput.setLocalisedHint("search_hint")

        // Dynamic — named tokens
        summaryView.formatText("greeting", "name" to "Alice", "count" to 3)

        // Dynamic — printf
        val intro = locf("profile_intro", "Alice", 30)

        // Observe language changes manually
        LocalisationManager.languageChanged.observe(this) {
            titleView.setLocalisedText("settings_title")
            summaryView.formatText("greeting", "name" to "Alice", "count" to 3)
        }
    }
}


// ═══════════════════════════════════════════════════════════════
// ALL PLACEHOLDER FORMATS — quick reference
// ═══════════════════════════════════════════════════════════════

// ── Named tokens {name} — RECOMMENDED ─────────────────────────
// Backend:  "Hi {name}, you have {count} messages"
// Code:     loc("greeting", "name" to "Alice", "count" to 5)
// Result:   "Hi Alice, you have 5 messages"
// Why best: backend can reorder args per language; code never changes

// ── printf-style %s %d %f ─────────────────────────────────────
// Backend:  "My name is %s and age is %d"
// Code:     locf("profile_intro", "Alice", 30)
// Result:   "My name is Alice and age is 30"
// Note:     uses Locale.ROOT — safe on Arabic/Persian devices

// ── Indexed {0} {1} ──────────────────────────────────────────
// Backend:  "Item {0} of {1}"
// Code:     LocalisationManager.format("item_label", "3", "10")
// Result:   "Item 3 of 10"

// ── Plurals — use key variants ────────────────────────────────
fun getMessageText(count: Int): String = when (count) {
    0    -> loc("messages_none")                          // "No messages"
    1    -> loc("messages_one")                           // "1 message"
    else -> loc("messages_many", "count" to count)        // "{count} messages"
}

// ── RecyclerView adapter ──────────────────────────────────────
class ItemAdapter : RecyclerView.Adapter<ItemAdapter.ViewHolder>() {
    inner class ViewHolder(v: View) : RecyclerView.ViewHolder(v) {
        val title:    TextView = v.findViewById(R.id.itemTitle)
        val subtitle: TextView = v.findViewById(R.id.itemSubtitle)
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.title.formatText("item_title", "name" to item.name)
        holder.subtitle.text = locf("item_date", item.formattedDate)
    }
    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        ViewHolder(LayoutInflater.from(p.context).inflate(R.layout.item_row, p, false))
    override fun getItemCount() = items.size
    private val items = listOf<Any>()
}


// ═══════════════════════════════════════════════════════════════
// strings.xml — English fallback keys
// Key names MUST match backend API keys exactly.
// ═══════════════════════════════════════════════════════════════

/*
<resources>
    <string name="welcome_title">Welcome</string>
    <string name="login_button">Log In</string>
    <string name="email_hint">Enter your email</string>
    <string name="greeting">Hi {name}, you have {count} messages</string>
    <string name="profile_intro">My name is %s and age is %d</string>
    <string name="item_label">Item {0} of {1}</string>
    <string name="messages_none">No messages</string>
    <string name="messages_one">1 message</string>
    <string name="messages_many">{count} messages</string>
    <string name="error_network">No internet connection</string>
    <string name="error_generic">Something went wrong</string>
</resources>
*/


// ═══════════════════════════════════════════════════════════════
// LANGUAGE CHANGE FLOW
// ═══════════════════════════════════════════════════════════════

/*
  User picks language
         ↓
  Your API call (existing code)
         ↓
  LocalisationManager.loadStrings("ar", apiResponse)
         ↓
  LiveData notifies all Activities & Fragments
         ↓
  LocalisationViewBinder.applyAll() → all tagged views update
         ↓
  onLocalisationApplied() → your dynamic views update

  No Activity restart. No recreate(). Instant.
*/


// ═══════════════════════════════════════════════════════════════
// DEBUG HELPERS
// ═══════════════════════════════════════════════════════════════

// Which level resolved a key?
val source = LocalisationManager.resolveSource("greeting")
// → StringSource.API           (from backend)
// → StringSource.XML_FALLBACK  (fell back to strings.xml)
// → StringSource.KEY_FALLBACK  (key not found anywhere)

// Is this key in the API response?
val exists = LocalisationManager.hasKey("welcome_title")

// Dump all loaded strings
val all = LocalisationManager.getAllStrings()

// Current language
val lang = LocalisationManager.currentLanguage

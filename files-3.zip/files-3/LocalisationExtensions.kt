package com.yourapp.localisation

import android.widget.Button
import android.widget.EditText
import android.widget.TextView

/**
 * ─────────────────────────────────────────────────────────────
 * LocalisationExtensions
 * ─────────────────────────────────────────────────────────────
 * Kotlin extension functions and shorthand helpers.
 * Import this file and use directly on any View or as top-level
 * functions anywhere in your code.
 *
 * ─── Static strings ───────────────────────────────────────────
 *   textView.setLocalisedText("welcome_title")
 *   editText.setLocalisedHint("email_hint")
 *   button.setLocalisedText("login_button")
 *
 * ─── Dynamic strings — named tokens (RECOMMENDED) ─────────────
 *   textView.formatText("greeting", "name" to "Alice", "count" to 5)
 *   editText.formatHint("search_hint", "category" to "Books")
 *
 * ─── Shorthand — use anywhere ─────────────────────────────────
 *   val title   = loc("welcome_title")
 *   val greeting = loc("greeting", "name" to "Alice")
 *   val intro    = locf("intro", "Alice", 30)   // printf-style
 * ─────────────────────────────────────────────────────────────
 */

// ── TextView ──────────────────────────────────────────────────

/** Bind static localised text. Auto-refreshes on language change. */
fun TextView.setLocalisedText(key: String) {
    text = LocalisationManager.getString(key)
    LocalisationViewBinder.bind(this, key)
}

/**
 * Bind dynamic text with named tokens.
 * Does NOT register for auto-refresh (dynamic args change per call).
 * Call again from onLocalisationApplied() if refresh is needed.
 */
fun TextView.formatText(key: String, vararg namedArgs: Pair<String, Any>) {
    text = LocalisationManager.format(key, *namedArgs)
}

// ── Button ────────────────────────────────────────────────────

fun Button.setLocalisedText(key: String) {
    text = LocalisationManager.getString(key)
    LocalisationViewBinder.bind(this, key)
}

fun Button.formatText(key: String, vararg namedArgs: Pair<String, Any>) {
    text = LocalisationManager.format(key, *namedArgs)
}

// ── EditText ──────────────────────────────────────────────────

fun EditText.setLocalisedHint(key: String) {
    hint = LocalisationManager.getString(key)
    LocalisationViewBinder.bind(this, key, LocalisationViewBinder.ViewProperty.HINT)
}

fun EditText.setLocalisedText(key: String) {
    setText(LocalisationManager.getString(key))
    LocalisationViewBinder.bind(this, key)
}

fun EditText.formatHint(key: String, vararg namedArgs: Pair<String, Any>) {
    hint = LocalisationManager.format(key, *namedArgs)
}

// ── Shorthand top-level functions ─────────────────────────────

/**
 * loc("key") — static string, no args.
 *   val title = loc("welcome_title")
 */
fun loc(key: String): String =
    LocalisationManager.getString(key)

/**
 * loc("key", "name" to "Alice") — named tokens. RECOMMENDED.
 *   val text = loc("greeting", "name" to "Alice", "count" to 5)
 *   Backend:  "Hi {name}, you have {count} messages"
 *   Result:   "Hi Alice, you have 5 messages"
 */
fun loc(key: String, vararg namedArgs: Pair<String, Any>): String =
    LocalisationManager.format(key, *namedArgs)

/**
 * locf("key", args) — printf-style %s %d %f.
 *   val text = locf("intro", "Alice", 30)
 *   Backend:  "My name is %s and age is %d"
 *   Result:   "My name is Alice and age is 30"
 *
 *   Uses Locale.ROOT internally — safe on Arabic/Persian devices.
 *   For XML fallback strings uses context.getString(resId, args).
 */
fun locf(key: String, vararg printfArgs: Any): String =
    LocalisationManager.format(key, *printfArgs)

package com.yourapp.localisation

import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment

/**
 * ─────────────────────────────────────────────────────────────
 * LocalisationActivity
 * ─────────────────────────────────────────────────────────────
 * Base Activity that wires up automatic localisation.
 * Extend this instead of AppCompatActivity.
 *
 * What you get for free:
 *   • All views tagged  android:tag="loc:key"  are bound and
 *     populated as soon as strings are loaded.
 *   • All bound views re-populate automatically when language
 *     changes — no recreate() needed.
 *   • onLocalisationApplied() callback for any extra UI work.
 *
 * Usage:
 *   class HomeActivity : LocalisationActivity() {
 *       override fun onCreate(...) {
 *           super.onCreate(...)
 *           setContentView(R.layout.activity_home)
 *           // tag-based views auto-bound; or call manually:
 *           myDynamicView.formatText("greeting", "name" to userName)
 *       }
 *       override fun onLocalisationApplied() {
 *           // strings are live — update anything tag-based won't cover
 *       }
 *   }
 * ─────────────────────────────────────────────────────────────
 */
abstract class LocalisationActivity : AppCompatActivity() {

    override fun onStart() {
        super.onStart()

        // Re-apply on every language change
        LocalisationManager.languageChanged.observe(this) { lang ->
            onLanguageChanged(lang)
            LocalisationViewBinder.applyAll()
            onLocalisationApplied()
        }

        // Apply immediately if strings already loaded, else wait
        if (LocalisationManager.localisationReady.value == true) {
            LocalisationViewBinder.bindActivity(this)
            onLocalisationApplied()
        } else {
            LocalisationManager.localisationReady.observe(this) { ready ->
                if (ready) {
                    LocalisationViewBinder.bindActivity(this)
                    onLocalisationApplied()
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        LocalisationViewBinder.clearBindings()
    }

    /** Called after strings are applied to all tagged views. Override for extra UI work. */
    open fun onLocalisationApplied() {}

    /** Called when user switches language. Override to react before views re-bind. */
    open fun onLanguageChanged(language: String) {}
}

/**
 * ─────────────────────────────────────────────────────────────
 * LocalisationFragment
 * ─────────────────────────────────────────────────────────────
 * Base Fragment — same behaviour as LocalisationActivity.
 * Extend this instead of Fragment.
 *
 * Usage:
 *   class ProfileFragment : LocalisationFragment() {
 *       override fun onViewCreated(view: View, ...) {
 *           super.onViewCreated(view, ...)
 *           // tag-based views in this fragment's layout auto-bound
 *       }
 *       override fun onLocalisationApplied() {
 *           // optional extra work after strings applied
 *       }
 *   }
 * ─────────────────────────────────────────────────────────────
 */
abstract class LocalisationFragment : Fragment() {

    override fun onStart() {
        super.onStart()

        LocalisationManager.languageChanged.observe(viewLifecycleOwner) { lang ->
            onLanguageChanged(lang)
            LocalisationViewBinder.applyAll()
            onLocalisationApplied()
        }

        if (LocalisationManager.localisationReady.value == true) {
            view?.let { LocalisationViewBinder.bindView(it) }
            onLocalisationApplied()
        } else {
            LocalisationManager.localisationReady.observe(viewLifecycleOwner) { ready ->
                if (ready) {
                    view?.let { LocalisationViewBinder.bindView(it) }
                    onLocalisationApplied()
                }
            }
        }
    }

    open fun onLocalisationApplied() {}
    open fun onLanguageChanged(language: String) {}
}
